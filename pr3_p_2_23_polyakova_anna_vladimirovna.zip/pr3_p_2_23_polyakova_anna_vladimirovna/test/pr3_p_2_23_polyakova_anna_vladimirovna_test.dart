import 'package:pr3_p_2_23_polyakova_anna_vladimirovna/pr3_p_2_23_polyakova_anna_vladimirovna.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
